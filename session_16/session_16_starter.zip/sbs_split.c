#include "libsbs.h"
#include <stdlib.h>

/*
 * TODO(과제 1~2): 문자열 s를 구분자 c로 쪼개 char ** 배열을 만든다.
 *  - 연속·앞뒤 구분자는 무시 (빈 단어 안 만듦)
 *  - 배열 끝은 NULL, 크기는 단어 수 + 1
 *  - 각 단어는 sbs_substr로 복사 (11차시 함수 재사용)
 *  - s == NULL이면 NULL
 * 힌트는 실습 페이지 과제 1~2 참고.
 */

/* 과제 1: 구분자로 나뉜 단어 개수를 센다 */
static size_t	count_words(const char *s, char c)
{
	(void)s;
	(void)c;
	/* TODO: 구현 */
	return (0);
}

/* 실패 시 지금까지 만든 단어 n개 + 배열을 해제 */
static void	free_partial(char **arr, size_t n)
{
	while (n > 0)
		free(arr[--n]);
	free(arr);
}

char	**sbs_split(const char *s, char c)
{
	(void)s;
	(void)c;
	(void)count_words;
	(void)free_partial;
	/* TODO(과제 2): 배열 malloc → 단어마다 sbs_substr로 복사 → 끝에 NULL */
	return (NULL);
}
