#include <stdio.h>
#include <stdlib.h>
#include "libsbs.h"

/*
 * minishell (16차시 종합 프로젝트) — 스켈레톤
 *
 * 채울 곳: builtin_echo / builtin_upper / builtin_len / builtin_help
 *          run_command 의 디스패치, main 의 split/free 연결
 * 힌트는 실습 페이지 과제 4~5 참고.
 */

#define BUF_SIZE 1024

static void	strip_newline(char *line)
{
	size_t	len;

	len = sbs_strlen(line);
	if (len > 0 && line[len - 1] == '\n')
		line[len - 1] = '\0';
}

/* 과제 4: args[1]부터 공백으로 이어 출력 */
static void	builtin_echo(char **args)
{
	(void)args;
	/* TODO */
}

/* 과제 4: 각 글자를 sbs_toupper로 대문자 출력 */
static void	builtin_upper(char **args)
{
	(void)args;
	/* TODO */
}

/* 과제 4: 각 인자를 sbs_strlen으로 길이 출력 */
static void	builtin_len(char **args)
{
	(void)args;
	/* TODO */
}

/* 과제 4: 명령 목록 출력 */
static void	builtin_help(void)
{
	/* TODO */
}

/*
 * 과제 5: 명령 해석 + 실행.
 *   - args[0] == NULL(빈 줄)을 가장 먼저 검사
 *   - exit면 1 반환(종료 신호), 그 외 0
 *   - 없는 명령은 "minishell: 이름: command not found"
 */
static int	run_command(char **args)
{
	(void)args;
	(void)builtin_echo;
	(void)builtin_upper;
	(void)builtin_len;
	(void)builtin_help;
	/* TODO */
	return (0);
}

int	main(void)
{
	char	line[BUF_SIZE];
	char	**args;
	int		done;

	done = 0;
	while (!done)
	{
		printf("minishell$ ");
		fflush(stdout);
		if (fgets(line, BUF_SIZE, stdin) == NULL)
		{
			printf("\n");
			break ;
		}
		strip_newline(line);
		/* TODO(과제 5): split → run_command → free_split */
		args = NULL;
		(void)args;
		done = 1;   /* TODO: 지우고 위 흐름으로 교체 */
	}
	printf("bye\n");
	return (0);
}
