#ifndef LIBSBS_H
# define LIBSBS_H

# include <stddef.h>

/* 9차시 — 문자 분류/변환 */
int		sbs_isalpha(int c);
int		sbs_isdigit(int c);
int		sbs_isalnum(int c);
int		sbs_isascii(int c);
int		sbs_isprint(int c);
int		sbs_toupper(int c);
int		sbs_tolower(int c);

/* 10차시 — 메모리 함수 I */
void	*sbs_memset(void *b, int c, size_t len);
void	sbs_bzero(void *s, size_t n);
void	*sbs_memcpy(void *dst, const void *src, size_t n);
void	*sbs_memccpy(void *dst, const void *src, int c, size_t n);

/* 11차시 — 메모리 함수 II */
void	*sbs_memmove(void *dst, const void *src, size_t len);
void	*sbs_memchr(const void *s, int c, size_t n);
int		sbs_memcmp(const void *s1, const void *s2, size_t n);
void	*sbs_calloc(size_t count, size_t size);

/* 12차시 — 문자열 함수 I */
size_t	sbs_strlen(const char *s);
size_t	sbs_strlcpy(char *dst, const char *src, size_t dstsize);
size_t	sbs_strlcat(char *dst, const char *src, size_t dstsize);

/* 13차시 — 문자열 함수 II */
char	*sbs_strchr(const char *s, int c);
char	*sbs_strrchr(const char *s, int c);
char	*sbs_strnstr(const char *big, const char *little, size_t len);

/* 14차시 — 문자열 함수 III */
int		sbs_strncmp(const char *s1, const char *s2, size_t n);
int		sbs_atoi(const char *str);
char	*sbs_strdup(const char *s);

#endif
