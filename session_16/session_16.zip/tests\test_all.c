#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "libsbs.h"

/*
 * 종합 통합 테스트: libsbs.a를 링크해 24개 함수를 대표값으로 검증.
 * grade.sh가 이 파일을 libsbs.a와 함께 빌드/실행한다.
 * 모든 검사를 통과하면 "ALL_OK" 출력 + 0 반환.
 */

static int	g_fail;

static void	check(int cond, const char *name)
{
	if (!cond)
	{
		printf("  [FAIL] %s\n", name);
		g_fail++;
	}
}

int	main(void)
{
	char	buf[32];
	char	*dup;

	g_fail = 0;

	/* 9차시 */
	check(sbs_isalpha('A') && !sbs_isalpha('5'), "isalpha");
	check(sbs_isdigit('7') && !sbs_isdigit('x'), "isdigit");
	check(sbs_isalnum('a') && sbs_isalnum('9') && !sbs_isalnum(' '), "isalnum");
	check(sbs_isascii(0) && sbs_isascii(127) && !sbs_isascii(200), "isascii");
	check(sbs_isprint(' ') && !sbs_isprint(127), "isprint");
	check(sbs_toupper('a') == 'A' && sbs_toupper('5') == '5', "toupper");
	check(sbs_tolower('Z') == 'z' && sbs_tolower('5') == '5', "tolower");

	/* 10차시 */
	sbs_memset(buf, 'x', 5);
	check(buf[0] == 'x' && buf[4] == 'x', "memset");
	sbs_bzero(buf, 5);
	check(buf[0] == 0 && buf[4] == 0, "bzero");
	sbs_memcpy(buf, "hello", 6);
	check(memcmp(buf, "hello", 6) == 0, "memcpy");
	check(sbs_memccpy(buf, "abcd", 'c', 4) != NULL, "memccpy");

	/* 11차시 */
	sbs_memcpy(buf, "123456", 7);
	sbs_memmove(buf + 2, buf, 4);
	check(memcmp(buf, "121234", 6) == 0, "memmove");
	check(sbs_memchr("hello", 'l', 5) != NULL && sbs_memchr("hello", 'z', 5) == NULL, "memchr");
	check(sbs_memcmp("abc", "abc", 3) == 0 && sbs_memcmp("abc", "abd", 3) < 0, "memcmp");
	dup = (char *)sbs_calloc(4, 2);
	check(dup != NULL && dup[0] == 0 && dup[7] == 0, "calloc");
	free(dup);

	/* 12차시 */
	check(sbs_strlen("hello") == 5 && sbs_strlen("") == 0, "strlen");
	sbs_strlcpy(buf, "hi", 32);
	check(strcmp(buf, "hi") == 0, "strlcpy");
	sbs_strlcat(buf, "!!", 32);
	check(strcmp(buf, "hi!!") == 0, "strlcat");

	/* 13차시 */
	check(sbs_strchr("hello", 'e') != NULL && sbs_strchr("hello", 'z') == NULL, "strchr");
	{
		const char	*hl = "hello";
		check(sbs_strrchr(hl, 'l') == hl + 3, "strrchr");
	}
	check(sbs_strnstr("hello world", "world", 11) != NULL
		&& sbs_strnstr("hello", "xyz", 5) == NULL, "strnstr");

	/* 14차시 */
	check(sbs_strncmp("abc", "abc", 3) == 0 && sbs_strncmp("abc", "abd", 3) < 0, "strncmp");
	check(sbs_atoi("  -42") == -42 && sbs_atoi("12ab") == 12 && sbs_atoi("abc") == 0, "atoi");
	dup = sbs_strdup("libsbs");
	check(dup != NULL && strcmp(dup, "libsbs") == 0 && dup != (char *)"libsbs", "strdup");
	free(dup);

	if (g_fail == 0)
	{
		printf("ALL_OK\n");
		return (0);
	}
	printf("FAILED: %d\n", g_fail);
	return (1);
}
