# 10차시 실습 - 메모리 함수 I

## 실습 목표

- `void *`를 `unsigned char *`로 캐스팅해 바이트 단위로 다룬다.
- `sbs_memset`, `sbs_bzero`, `sbs_memcpy`, `sbs_memccpy`를 구현한다.
- `bash grade.sh`로 표준 함수와 비교해 자동 채점한다.

## 시간: 90분

> **표준 헤더 우회 금지**: `<string.h>`, `<strings.h>`를 include하면 안 됩니다. 직접 구현해야 합니다.

---

## 준비: libsbs.h에 추가

9차시 `libsbs.h`에 4개 프로토타입을 **추가**합니다 (기존 7개는 그대로). 길이 타입 `size_t`를 위해 `# include <stddef.h>`도 추가.

```c
# include <stddef.h>
/* ... 9차시 문자 함수 7개 ... */

void	*sbs_memset(void *b, int c, size_t len);
void	sbs_bzero(void *s, size_t n);
void	*sbs_memcpy(void *dst, const void *src, size_t n);
void	*sbs_memccpy(void *dst, const void *src, int c, size_t n);
```

> 이번 차시 폴더에는 메모리 함수 4개만 채점합니다. 9차시 문자 함수는 가져오지 않아도 됩니다(헤더 선언은 있어도 무방).

---

## 과제 1: sbs_memset (15분)

`sbs_memset.c` — `b`부터 `len`바이트를 값 `c`로 채우고 `b` 반환.

```c
#include "libsbs.h"

void	*sbs_memset(void *b, int c, size_t len)
{
    unsigned char	*p;
    size_t			i;

    p = (unsigned char *)b;
    i = 0;
    while (i < len)
    {
        p[i] = (unsigned char)c;
        i++;
    }
    return (b);
}
```

> `man 3 memset`로 명세 확인. 반환값은 첫 인자 `b` 그대로.

---

## 과제 2: sbs_bzero (10분)

`sbs_bzero.c` — `s`부터 `n`바이트를 0으로. **반환값 없음(void)**.

힌트: 방금 만든 `sbs_memset`을 재사용.
```c
void	sbs_bzero(void *s, size_t n)
{
    sbs_memset(s, 0, n);
}
```

---

## 과제 3: sbs_memcpy (20분)

`sbs_memcpy.c` — `src`에서 `dst`로 `n`바이트 복사, `dst` 반환.

요구사항:
- `dst`는 `unsigned char *`, `src`는 `const unsigned char *`로 캐스팅
- 한 바이트씩 복사

힌트:
```c
unsigned char       *d = (unsigned char *)dst;
const unsigned char *s = (const unsigned char *)src;
```

> `src`에 `const`를 붙이는 이유: 원본은 읽기만 하기 때문(5차시 심화).

---

## 과제 4: sbs_memccpy (25분)

`sbs_memccpy.c` — `src`를 `dst`로 복사하되 문자 `c`를 만나면 **그 문자까지 복사 후 멈춤**.

반환값 규칙 (가장 헷갈리는 부분):
- `c`를 찾으면 → `dst`에서 **그 문자 다음 위치** 포인터
- 못 찾으면 → `NULL`

힌트:
```c
while (i < n)
{
    d[i] = s[i];
    if (s[i] == (unsigned char)c)
        return (d + i + 1);   // 찾음
    i++;
}
return (NULL);                // 못 찾음
```

> `man 3 memccpy`로 반환값을 꼭 확인하세요. `(unsigned char)c`로 비교하는 것에 주의.

---

## 과제 5: 채점 실행 (10분)

```bash
$ bash grade.sh
=== libsbs 10차시 채점 ===
✓ sbs_memset    (20/20)
✓ sbs_bzero     (4/4)
✓ sbs_memcpy    (5/5)
✓ sbs_memccpy   (16/16)
결과: 4 / 4 통과
```

실패 시: `bash grade.sh -v`로 어떤 길이/값에서 틀렸는지 확인.

> zip으로 받았으면 `bash grade.sh`로 실행(권한 없어도 됨). `./grade.sh`를 쓰려면 `chmod +x grade.sh`.

---

## 제출 확인 사항

- [ ] `libsbs.h`에 `<stddef.h>` + 4개 프로토타입 추가
- [ ] `sbs_memset.c` - 값으로 채우고 b 반환
- [ ] `sbs_bzero.c` - 0으로 채움 (memset 재사용)
- [ ] `sbs_memcpy.c` - n바이트 복사, const src
- [ ] `sbs_memccpy.c` - c 찾으면 다음 위치, 못 찾으면 NULL
- [ ] `<string.h>`, `<strings.h>` 미사용
- [ ] `bash grade.sh` → 4 / 4 통과

---

## 더 생각해볼 거리

1. `unsigned char`가 아니라 `char`로 캐스팅하면 어떤 문제가 생길까? (음수 바이트)
2. `memcpy`로 겹치는 영역을 복사하면 왜 위험할까? (11차시 memmove의 동기)
3. `memccpy`에서 `n`이 0이면? (한 바이트도 복사 안 하고 NULL)
