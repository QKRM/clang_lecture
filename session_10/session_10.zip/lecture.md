# 10차시 강의 노트 - 메모리 함수 I (memset, bzero, memcpy, memccpy)

## 학습 목표

1. `void *`(범용 포인터)의 개념과 용도를 설명할 수 있다.
2. `unsigned char *`로 캐스팅해 바이트 단위로 메모리를 다룰 수 있다.
3. `sbs_memset`, `sbs_bzero`를 구현할 수 있다.
4. `sbs_memcpy`, `sbs_memccpy`를 구현하고 반환값 규칙을 설명할 수 있다.

## 시간 배분

| 구분 | 내용 | 시간 |
|------|------|------|
| 강사 설명 | void*, 바이트 복사 원리, 4개 함수 명세 분석 | 90분 |
| 실습 | libsbs.h에 추가 + 4개 함수 구현 + grade.sh 채점 | 90분 |

---

## 1부: void 포인터 (20분)

### 1.1 타입을 가리지 않는 포인터

`void *`는 "어떤 타입이든 가리킬 수 있는 주소"입니다. 메모리 함수는 int든 구조체든 문자열이든 받아야 하므로 `void *`로 받습니다.

```c
void *sbs_memset(void *b, int c, size_t len);
```

`b`가 무엇을 가리키는지 모르므로, **역참조하려면 구체적 타입으로 캐스팅**해야 합니다.

### 1.2 size_t

크기·길이를 담는 부호 없는 정수 타입입니다(2차시). 메모리 함수의 길이 인자는 항상 `size_t`. `<stddef.h>`에 정의되어 있어 헤더에 `# include <stddef.h>`를 넣습니다.

---

## 2부: 바이트 단위로 다루기 (20분)

### 2.1 왜 unsigned char인가?

메모리를 1바이트씩 다루려면 1바이트 타입이 필요합니다. `char`는 부호가 있어 음수가 섞이면 곤란하므로, **`unsigned char`(0~255)** 로 캐스팅합니다.

```c
unsigned char *p = (unsigned char *)b;
p[i] = (unsigned char)c;   // 한 바이트씩 채움
```

> 2차시 `ft_memset` 미리보기에서 본 캐스팅이 바로 이것입니다.

### 2.2 const의 의미

`memcpy(void *dst, const void *src, size_t n)` — `src`는 **읽기만** 하므로 `const`(5차시 심화). 실수로 원본을 바꾸면 컴파일 에러로 막힙니다.

---

## 3부: 4개 함수 명세 (35분)

### 3.1 sbs_memset — 특정 값으로 채우기

`b`부터 `len`바이트를 값 `c`로 채우고, `b`를 반환합니다.

```c
void *sbs_memset(void *b, int c, size_t len)
{
    unsigned char *p = (unsigned char *)b;
    size_t i = 0;
    while (i < len)
    {
        p[i] = (unsigned char)c;
        i++;
    }
    return (b);
}
```

### 3.2 sbs_bzero — 0으로 채우기

`memset`의 특수형. `s`부터 `n`바이트를 0으로 채웁니다. **반환값 없음(void)**. memset 재사용이 깔끔합니다.

```c
void sbs_bzero(void *s, size_t n)
{
    sbs_memset(s, 0, n);
}
```

### 3.3 sbs_memcpy — 메모리 복사

`src`에서 `dst`로 `n`바이트 복사, `dst` 반환. **겹치는 영역은 보장하지 않음**(겹침 처리는 11차시 memmove).

```c
void *sbs_memcpy(void *dst, const void *src, size_t n)
{
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    size_t i = 0;
    while (i < n)
    {
        d[i] = s[i];
        i++;
    }
    return (dst);
}
```

### 3.4 sbs_memccpy — 특정 문자까지 복사

`src`를 `dst`로 복사하되, 문자 `c`를 만나면 **그 문자까지 복사한 뒤 멈춤**. 반환값 규칙이 핵심:

- `c`를 찾으면 → `dst`에서 **그 문자 다음 위치**의 포인터
- 못 찾고 `n`바이트 다 복사 → `NULL`

```c
void *sbs_memccpy(void *dst, const void *src, int c, size_t n)
{
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    size_t i = 0;
    while (i < n)
    {
        d[i] = s[i];
        if (s[i] == (unsigned char)c)
            return (d + i + 1);   // 찾음: 다음 위치
        i++;
    }
    return (NULL);                 // 못 찾음
}
```

> `man 3 memccpy`로 반환값 규칙을 꼭 확인하세요. "찾으면 다음 위치, 못 찾으면 NULL"이 헷갈리는 부분입니다.

---

## 4부: 채점 (15분)

`libsbs.h`에 9차시 함수 아래로 4개 프로토타입을 **추가**합니다(덮어쓰지 말 것).

```bash
$ bash grade.sh        # 요약
$ bash grade.sh -v     # 실패 상세
```

채점은 표준 `memset/bzero/memcpy/memccpy`와 **버퍼 내용 + 반환 포인터**를 비교합니다. 여러 길이·값·정지문자 조합으로 검사합니다.

> 금지: `<string.h>`, `<strings.h>`. 직접 구현해야 합니다.

---

## 핵심 정리

1. `void *` = 타입 안 가리는 주소 → 역참조하려면 캐스팅
2. 메모리는 **`unsigned char *`** 로 바이트 단위 처리
3. `memset`은 값으로 채우고 포인터 반환, `bzero`는 0으로 채우고 반환 없음
4. `memcpy`는 n바이트 복사(겹침 미보장), `dst` 반환
5. `memccpy`는 c를 찾으면 **다음 위치**, 못 찾으면 **NULL**
6. `src`는 `const` — 읽기 전용

---

## 다음 차시 예고

11차시에서는 메모리 함수 II(`sbs_memmove`, `sbs_memchr`, `sbs_memcmp`, `sbs_calloc`)을 구현합니다. memcpy와 달리 **겹치는 메모리**를 안전하게 다루는 memmove, 그리고 `malloc`/`free`로 동적 메모리를 할당하는 calloc을 배웁니다.
