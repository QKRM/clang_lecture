# 12차시 강의 노트 - 문자열 함수 I (strlen, strlcpy, strlcat)

## 학습 목표

1. `sbs_strlen`을 구현하고 null terminator 처리를 이해한다.
2. 버퍼 오버플로우의 위험과 "버퍼 안전" 함수의 필요성을 설명한다.
3. `sbs_strlcpy`의 반환값과 크기 처리를 구현한다.
4. `sbs_strlcat`의 이어붙이기와 반환값 규칙을 구현한다.

## 시간 배분

| 구분 | 내용 | 시간 |
|------|------|------|
| 강사 설명 | strlen, 버퍼 오버플로우, strlcpy/strlcat 명세 | 90분 |
| 실습 | libsbs.h 추가 + 3개 함수 구현 + 버퍼 안전성 테스트 | 90분 |

---

## 1부: sbs_strlen (15분)

7차시에서 본 길이 세기를 함수로 만듭니다. `\0`까지 글자 수를 셉니다.

```c
size_t sbs_strlen(const char *s)
{
    size_t len = 0;
    while (s[len])
        len++;
    return (len);
}
```

- 반환 타입 `size_t`(부호 없는 크기 타입, 2차시)
- 읽기만 하므로 `const char *`

> 모든 문자열 함수가 길이를 알아야 하므로 `sbs_strlen`을 먼저 만들고 재사용합니다.

---

## 2부: 버퍼 오버플로우 (20분)

### 2.1 strcpy의 위험

표준 `strcpy(dst, src)`는 dst 크기를 모릅니다. src가 dst보다 길면 **버퍼를 넘어 다른 메모리를 덮어씁니다**(버퍼 오버플로우 — 심각한 보안 취약점).

```c
char dst[4];
strcpy(dst, "hello");   // 5글자+\0 = 6바이트를 4바이트에! → 오버플로우
```

### 2.2 strlcpy / strlcat의 해법

크기 인자 `dstsize`를 받아 **절대 버퍼를 넘지 않습니다**. 항상 `\0`로 끝맺습니다(dstsize>0일 때).

| 함수 | 역할 |
|------|------|
| `strlcpy(dst, src, size)` | 안전 복사 |
| `strlcat(dst, src, size)` | 안전 이어붙이기 |

> BSD 계열에서 만든 안전 버전. 반환값으로 "원래 만들려던 길이"를 알려줘 잘림을 감지할 수 있습니다.

---

## 3부: sbs_strlcpy (25분)

`src`를 `dst`로 복사하되 최대 `dstsize-1`글자 + `\0`. **반환값은 src의 전체 길이**(잘림 감지용).

```c
size_t sbs_strlcpy(char *dst, const char *src, size_t dstsize)
{
    size_t srclen = sbs_strlen(src);
    size_t i;

    if (dstsize == 0)           // 쓸 공간 없으면
        return (srclen);        // 길이만 반환
    i = 0;
    while (src[i] && i < dstsize - 1)
    {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';              // 항상 종결
    return (srclen);
}
```

핵심 포인트:
- `dstsize == 0` 예외 처리(아무것도 안 씀)
- `i < dstsize - 1`로 마지막 `\0` 자리 확보
- 반환값은 **복사한 수가 아니라 src 전체 길이**

> 반환값 >= dstsize이면 잘렸다는 뜻입니다.

---

## 4부: sbs_strlcat (25분)

`dst`의 기존 문자열 **뒤에** `src`를 이어붙입니다. 버퍼 안전. 반환값 규칙이 까다롭습니다.

```c
size_t sbs_strlcat(char *dst, const char *src, size_t dstsize)
{
    size_t srclen = sbs_strlen(src);
    size_t dstlen;
    size_t i;

    if (dstsize == 0)
        return (srclen);
    dstlen = 0;
    while (dstlen < dstsize && dst[dstlen])   // dstsize 안에서만 길이 측정
        dstlen++;
    if (dstlen == dstsize)                     // dst에 \0이 없음
        return (dstsize + srclen);
    i = 0;
    while (src[i] && dstlen + i < dstsize - 1)
    {
        dst[dstlen + i] = src[i];
        i++;
    }
    dst[dstlen + i] = '\0';
    return (dstlen + srclen);                  // 만들려던 전체 길이
}
```

핵심 포인트:
- dst 길이를 **dstsize 안에서만** 측정(넘어가면 위험)
- dst가 dstsize 안에 `\0`이 없으면 `dstsize + srclen` 반환
- 정상: 반환값 = `dstlen + srclen`(원래 만들려던 길이)

> `man 3 strlcat`로 반환값 규칙을 꼭 확인하세요. 가장 헷갈리는 함수입니다.

---

## 5부: 채점 (5분)

`strlen`은 표준과 비교하지만, `strlcpy`/`strlcat`은 glibc에 없을 수 있어 **테스트 안에 정답 동작을 구현**해 비교합니다. 여러 크기·잘림 상황을 검사합니다.

```bash
$ bash grade.sh
✓ sbs_strlen    (...)
✓ sbs_strlcpy   (...)
✓ sbs_strlcat   (...)
결과: 3 / 3 통과
```

---

## 핵심 정리

1. `sbs_strlen`은 `\0`까지 세고 `size_t` 반환, 다른 함수가 재사용
2. `strcpy`는 크기를 몰라 **버퍼 오버플로우** 위험
3. `strlcpy/strlcat`은 `dstsize`로 안전, 항상 `\0` 종결
4. strlcpy 반환값 = **src 전체 길이**(잘림 감지)
5. strlcat은 dst 길이를 dstsize 안에서만 측정, 반환 = `dstlen + srclen`
6. 두 함수 모두 `dstsize == 0` 예외 처리

---

## 다음 차시 예고

13차시에서는 문자열 함수 II(`sbs_strchr`, `sbs_strrchr`, `sbs_strnstr`)를 구현합니다. 문자열에서 문자를 순방향·역방향으로 찾고, 부분 문자열을 검색합니다.
