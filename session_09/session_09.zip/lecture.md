# 9차시 강의 노트 - 헤더 파일 + 문자 분류 함수 구현

## 학습 목표

1. 헤더 파일(`.h`)의 역할과 "선언/정의 분리"를 설명할 수 있다.
2. `#include "libsbs.h"`로 직접 만든 헤더를 포함하고 `<>`와 `""`의 차이를 안다.
3. 인클루드 가드(`#ifndef / #define / #endif`)로 중복 포함을 막을 수 있다.
4. ASCII 코드 체계를 이해하고 문자 분류 기준을 설명할 수 있다.
5. `sbs_isalpha`, `sbs_isdigit`, `sbs_isalnum`, `sbs_isascii`, `sbs_isprint`, `sbs_toupper`, `sbs_tolower`를 구현할 수 있다.

## 시간 배분

| 구분 | 내용 | 시간 |
|------|------|------|
| 강사 설명 | 헤더 파일 개념, 인클루드 가드, ASCII, 7개 함수 명세 분석 | 90분 |
| 실습 | libsbs.h 작성 + 7개 함수 구현 + 채점 스크립트로 자동 테스트 | 90분 |

> **9차시부터 libsbs 본격 구현 시작.** 지금까지 배운 함수·포인터·문자·조건문이 모두 모입니다.

---

## 1부: 헤더 파일이란? (25분)

### 1.1 선언과 정의의 분리

지금까지는 프로토타입과 함수를 한 파일에 뒀습니다(4차시). 함수가 많아지면 **선언(프로토타입)은 헤더 파일(.h)에, 정의(본문)는 소스 파일(.c)에** 나눕니다.

```c
/* libsbs.h — 선언만 모음 */
int   sbs_isalpha(int c);
int   sbs_toupper(int c);

/* sbs_isalpha.c — 정의(본문) */
#include "libsbs.h"

int sbs_isalpha(int c)
{
    ...
}
```

### 1.2 왜 나누나?

- 여러 .c 파일이 같은 함수를 쓸 때, 헤더 하나만 `#include`하면 됨.
- 함수 목록(API)을 헤더만 보고 파악 가능.
- 16차시에서 `libsbs.h` 하나로 전체 라이브러리를 묶습니다.

### 1.3 `#include "..."` vs `<...>`

```c
#include <stdio.h>     // 시스템 헤더 — 표준 경로에서 찾음
#include "libsbs.h"    // 내 헤더 — 현재 폴더에서 먼저 찾음
```

| 형식 | 찾는 위치 | 용도 |
|------|-----------|------|
| `<stdio.h>` | 시스템 표준 경로 | 표준 라이브러리 |
| `"libsbs.h"` | 현재 디렉토리 우선 | 내가 만든 헤더 |

---

## 2부: 인클루드 가드 (15분)

### 2.1 중복 포함 문제

같은 헤더가 두 번 `#include`되면 선언이 중복되어 에러가 납니다. 큰 프로젝트에서 흔히 발생합니다.

### 2.2 인클루드 가드로 방어

헤더를 다음 틀로 감쌉니다. 한 번 포함되면 매크로가 정의되어, 두 번째부터는 건너뜁니다.

```c
#ifndef LIBSBS_H      // LIBSBS_H가 정의 안 됐으면
# define LIBSBS_H     // 정의하고

/* ── 여기에 함수 프로토타입들 ── */
int   sbs_isalpha(int c);
int   sbs_isdigit(int c);
int   sbs_isalnum(int c);
int   sbs_isascii(int c);
int   sbs_isprint(int c);
int   sbs_toupper(int c);
int   sbs_tolower(int c);

#endif                // 여기까지만 포함
```

> 매크로 이름은 보통 파일명을 대문자로 (`LIBSBS_H`). 이 세 줄(`#ifndef / #define / #endif`)이 한 세트입니다.

---

## 3부: ASCII 코드 복습 (15분)

7차시에서 본 "문자는 정수"를 다시 확인합니다. 문자 분류 함수는 전부 ASCII 범위 판별입니다.

| 범위 | 문자 | 의미 |
|------|------|------|
| 0–31, 127 | 제어 문자 | 출력 불가 |
| 32 | 공백 | 출력 가능 시작 |
| 32–126 | 출력 가능 | isprint 범위 |
| 48–57 | `'0'`–`'9'` | 숫자 문자 |
| 65–90 | `'A'`–`'Z'` | 대문자 |
| 97–122 | `'a'`–`'z'` | 소문자 |

```c
c >= 'a' && c <= 'z'   // 소문자 판별
c >= '0' && c <= '9'   // 숫자 판별
c - 32                 // 소문자 → 대문자
c + 32                 // 대문자 → 소문자
```

> `man 3 isalpha`로 표준 명세를 확인하세요(1차시 man 사용법). "참이면 0이 아닌 값, 거짓이면 0" 반환이 핵심.

---

## 4부: 7개 함수 명세 분석 (20분)

### 4.1 분류 함수 (is*)

모두 `int`를 받아 조건을 만족하면 **0이 아닌 값**, 아니면 **0**을 반환합니다.

```c
int sbs_isalpha(int c)   // 알파벳(a-z, A-Z)이면 참
{
    return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
}

int sbs_isdigit(int c)   // 숫자 문자(0-9)이면 참
{
    return (c >= '0' && c <= '9');
}

int sbs_isalnum(int c)   // 알파벳 또는 숫자
{
    return (sbs_isalpha(c) || sbs_isdigit(c));
}

int sbs_isascii(int c)   // ASCII 범위(0-127)이면 참
{
    return (c >= 0 && c <= 127);
}

int sbs_isprint(int c)   // 출력 가능 문자(32-126)이면 참
{
    return (c >= 32 && c <= 126);
}
```

> `sbs_isalnum`은 이미 만든 `sbs_isalpha`, `sbs_isdigit`를 재사용합니다. 작은 함수를 조합하는 감각이 라이브러리 설계의 핵심입니다.

### 4.2 변환 함수

변환 대상이 아니면 **원래 값 그대로** 반환합니다. 이 점을 빠뜨리기 쉽습니다.

```c
int sbs_toupper(int c)   // 소문자면 대문자로, 아니면 그대로
{
    if (c >= 'a' && c <= 'z')
        return (c - 32);
    return (c);
}

int sbs_tolower(int c)   // 대문자면 소문자로, 아니면 그대로
{
    if (c >= 'A' && c <= 'Z')
        return (c + 32);
    return (c);
}
```

---

## 5부: 채점 스크립트 사용법 (15분)

### 5.1 파일 구조

```
session_09/
├── libsbs.h            # 직접 작성 (프로토타입 + 인클루드 가드)
├── sbs_isalpha.c       # 함수별 1파일
├── sbs_isdigit.c
├── ...
├── grade.sh            # 채점 진입점
└── tests/              # 함수별 테스트 (수정 금지)
```

### 5.2 실행

```bash
$ bash grade.sh        # 전체 채점
$ bash grade.sh -v     # 실패 케이스 상세 출력
```

### 5.3 채점 기준

```
1단계: gcc -Wall -Wextra -Werror 컴파일 → 경고 1개라도 있으면 그 함수 0점
2단계: 표준 함수(libc)와 0~255 전 범위 비교 → 모두 일치해야 통과
```

출력 예시:

```
=== libsbs 9차시 채점 ===
✓ sbs_isalpha   (256/256)
✓ sbs_isdigit   (256/256)
✗ sbs_toupper   (254/256)  →  -v로 상세 확인
...
결과: 6 / 7 통과
```

> 표준 함수가 정답(oracle)입니다. 정답을 외울 필요 없이, libc와 똑같이 동작하면 통과입니다.

---

## 핵심 정리

1. 헤더(.h)는 **선언**, 소스(.c)는 **정의** — 역할을 나눈다
2. `#include "libsbs.h"`(내 헤더) vs `<stdio.h>`(시스템 헤더)
3. **인클루드 가드**(`#ifndef/#define/#endif`)로 중복 포함 방지
4. is* 함수는 조건 만족 시 **0이 아닌 값**, 아니면 0
5. 변환 함수는 대상이 아니면 **원래 값 그대로** 반환
6. `bash grade.sh`로 표준 함수와 비교해 자동 채점

---

## 다음 차시 예고

10차시에서는 메모리 함수 I(`sbs_memset`, `sbs_bzero`, `sbs_memcpy`, `sbs_memccpy`)을 구현합니다. `void *`(범용 포인터)의 개념과 바이트 단위 복사 원리를 다루고, 오늘 만든 `libsbs.h`에 함수를 계속 추가합니다. 채점 스크립트도 같은 방식으로 사용합니다.
